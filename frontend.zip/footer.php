  <footer class="footer mt-5">
    <img src="img/banner/footerde.jpg" style="width:100%">
      
            <div class="container">
                <div class="row mt-3">
                    <div class="col-lg-4"></div>
                    <div class="col-lg-4">
                    <div class="justify-content-center">
                       <center><a href=""><i class="fa fa-facebook-f" style="font-size:24px;color:#bc895a;margin-right:3%"></i></a>
                       <a href=""><i class="fa fa-instagram" style="font-size:24px;color:#bc895a;margin-right:3%"></i></a>
                       <a href=""><i class="fa fa-twitter" style="font-size:24px;color:#bc895a;margin-right:3%"></i></a></center>
                    </div>  
                    </div>
                    <div class="col-lg-4"></div>
                </div>

                <div class="row mt-4 pb-4">
                    <div class="container text-center">
                        <a href="feedback.php" class="text-white mr-3">Feedback</a>
                        <a href="customize.php" class="text-white mr-3">Customize Package</a>
                        <a href="contact.php" class="text-white mr-3">Contact</a>
                    </div>
                </div>
           
                <div class="row mt-3 pb-3">
                    <div class="container text-center">
                        <p href="" class="text-white mr-4" style="font-size:13px">Designed & Developed by <a style="color:#bc895a" target="_blank" href="http://pixsonik.com/">Pixsonik</a></p>
                    </div>
                </div>

        </div>


        <div class="copy-right_text" style="display: none">
            <div class="container">
                <div class="footer_border"></div>
                <div class="row">
                    <div class="col-xl-8 col-md-7 col-lg-9">
                        <p class="copy_right">
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                    </div>
                    <div class="col-xl-4 col-md-5 col-lg-3">
                        <div class="socail_links">
                            <ul>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-facebook-square"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-instagram"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>