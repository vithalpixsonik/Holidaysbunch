<?php
        if(isset($_POST['enquiry']))
        {   
        $name=$_POST['name'];
        $email=$_POST['email'];
        $contact=$_POST['contact'];
        $adult=$_POST['adult'];
        $child=$_POST['child'];
        $departure_city=$_POST['departure-city'];
        $destination_type=$_POST['type'];
        $destination=$_POST['destination'];
        $budget=$_POST['budget'];
        $stars=$_POST['stars'];
        $date=$_POST['date'];
        $description=$_POST['description'];
        
        $headers .= "Holiday Bunch Website <shubham.mhadgut24@gmail.com.com>". "\r\n"; 
        // Set content-type header for sending HTML email 
        $headers = "MIME-Version: 1.0" . "\r\n"; 
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
        $subject='New Enquiry For Customize Package';
        $message = '<h2>New Enquiry For Customize Package</h2>
    
        <h3>Passenger Details</h3>
        Name : '.$name.'<br>
        Email : '.$email.'<br>
        Contact : '.$contact.'<br>
        Adult : '.$adult.'<br>
        Child : '.$child.'<br>
        Departure City : '.$departure_city.'<br>

        <h3>Package Details</h3>
        Destination Type : '.$destination_type.'<br>
        Destination : '.$destination.'<br>
        Budget : '.$budget.'<br>
        Hotel Preferrence : '.$stars.'<br>
        Date : '.$date.'<br>
        Description : '.$description.'<br>
        
        ';
    
        mail("admin@holidaysbunch.com", $subject, $message, $headers);  
        
        header('Location: thanks.php');
        exit();
        }
    ?>